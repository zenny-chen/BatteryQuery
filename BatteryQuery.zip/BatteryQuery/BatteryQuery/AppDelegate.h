//
//  AppDelegate.h
//  BatteryQuery
//
//  Created by Zenny Chen on 2018/1/22.
//  Copyright © 2018年 GreenGames Studio. All rights reserved.
//

@import UIKit;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@end

