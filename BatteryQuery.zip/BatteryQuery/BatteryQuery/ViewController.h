//
//  ViewController.h
//  BatteryQuery
//
//  Created by Zenny Chen on 2018/1/22.
//  Copyright © 2018年 GreenGames Studio. All rights reserved.
//

@import UIKit;

#ifndef var
#define var     __auto_type
#endif

@interface ViewController : UIViewController

@end

